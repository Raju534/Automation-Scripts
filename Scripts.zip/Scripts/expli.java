package Scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class expli 
{
 public static void main(String[] args) 
 {
    System.setProperty("webdriver.chrome.driver","./Softwares/chromedriver.exe");
    WebDriver driver=new ChromeDriver();
    driver.manage().window().maximize();
    WebDriverWait wait=new WebDriverWait(driver, 10);
    driver.get("https://www.amazon.com");
    wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[.='Login']")))).click();
    driver.findElement(By.xpath("//div[.='usrename']")).sendKeys("automation");
    wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//div[.='pwd']")))).sendKeys("manual");
    wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//div[.='Lgin button']")))).click();
    
}
}
