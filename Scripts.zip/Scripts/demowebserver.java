package Scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class demowebserver 
{
   public static void main(String[] args) throws InterruptedException 
   {
	  System.setProperty("webdriver.chrome.driver","./softwares/chromedriver.exe");
	  WebDriver driver=new ChromeDriver();
	  driver.get("https://demowebshop.tricentis.com/");
	  Thread.sleep(2000);
	  driver.findElement(By.xpath("//a[@href='/books']")).click();
	  driver.findElement(By.xpath("//a[.='Computing and Internet']/../../div[3]/div[2]/input")).click();
	  Thread.sleep(2000);
	  driver.findElement(By.xpath("//a[.='Fiction']/../../div[3]/div[2]/input")).click();
	  Thread.sleep(2000);
	  driver.findElement(By.xpath("//input[@class='button-1 cart-button']")).click();
	  Thread.sleep(2000);
}
}
