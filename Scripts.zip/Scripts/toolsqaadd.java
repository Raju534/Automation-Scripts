package Scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class toolsqaadd 
{
  public static void main(String[] args) throws InterruptedException 
  {
	 System.setProperty("webdriver.chrome.driver","./softwares/chromedriver.exe");
	    WebDriver driver=new ChromeDriver();
	    driver.get("https://demoqa.com/webtables");
	    driver.findElement(By.xpath("//button[@id='addNewRecordButton']")).click();
	    Thread.sleep(4000);
	    driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys("raju");
	    driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys("h");
	    driver.findElement(By.xpath("//input[@id='userEmail']")).sendKeys("hiremathraju77@gmail.com");
	    driver.findElement(By.xpath("//input[@id='age']")).sendKeys("24");
	    driver.findElement(By.xpath("//input[@id='salary']")).sendKeys("25000");
	    driver.findElement(By.xpath("//input[@placeholder='Department']")).sendKeys("QA");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[@type='submit']")).click();
	     
}
}
