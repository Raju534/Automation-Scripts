package Scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class popup
{
  public static void main(String[] args) throws InterruptedException 
  {
	System.setProperty("webdriver.chrome.driver","./Softwares/chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("https://demoqa.com/upload-download");
	Thread.sleep(2000);
	WebElement browser = driver.findElement(By.id("uploadFile"));
	Thread.sleep(2000);
	browser.sendKeys("\"C:\\Users\\User\\Desktop\\scenarios.xlsx\"");
	Thread.sleep(2000);
	
}
}
