package Scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class doubleclick 
{
   public static void main(String[] args)
   {
	  System.setProperty("webdriver.chrome.driver","./Softwares/chromedriver.exe");
	  WebDriver driver=new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.get("https://demo.guru99.com/test/simple_context_menu.html");
	WebElement abc= driver.findElement(By.xpath("//button[.='Double-Click Me To See Alert']"));
	Actions click=new Actions(driver);
	click.doubleClick(abc).perform();
}
}
