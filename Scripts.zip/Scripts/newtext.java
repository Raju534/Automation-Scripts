package Scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class newtext 
{
   public static void main(String[] args) throws InterruptedException
   {
	  System.setProperty("webdriver.chrome.driver","./Softwares/chromedriver.exe");
	  WebDriver driver=new ChromeDriver();
	  driver.get("https://demoqa.com/text-box");
	  driver.findElement(By.xpath("//input[@type='text']")).sendKeys("raju hiremath");
	  driver.findElement(By.xpath("//input[@type='email']")).sendKeys("hiremathraju58@gmail.com");
	  driver.findElement(By.xpath("//textarea[@placeholder='Current Address']")).sendKeys("Bengaluru rajajinagar");
	  driver.findElement(By.xpath("//textarea[@id='permanentAddress']")).sendKeys("Bangaluru");
	  Thread.sleep(2000);
	  driver.findElement(By.xpath("//button[@id='submit']")).click();
	 }
}
