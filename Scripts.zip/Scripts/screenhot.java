package Scripts;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class screenhot 
{
   public static void main(String[] args) throws InterruptedException, IOException
   {
	  System.setProperty("webdriver.chrome.driver","./Softwares/chromedriver.exe");
	  WebDriver driver=new ChromeDriver();
	  driver.get("https://www.amazon.com");
	  Thread.sleep(2000);
	  TakesScreenshot tss=(TakesScreenshot)driver;
	  File src=tss.getScreenshotAs(OutputType.FILE);
	  File dst=new File("./photos/amazon.jpeg");
	  FileHandler.copy(src, dst);
}
}
