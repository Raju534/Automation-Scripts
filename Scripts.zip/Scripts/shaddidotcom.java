package Scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class shaddidotcom 
{
   public static void main(String[] args) throws InterruptedException 
   {
	  System.setProperty("webdriver.chrome.driver","./softwares/chromedriver.exe");
	   WebDriver driver=new ChromeDriver();
	   driver.get("https://www.shaadi.com");
	   Thread.sleep(4000);
	    driver.findElement(By.xpath("//a[@data-testid='login_link']")).click();
	    driver.findElement(By.xpath("//input[@type='text']")).sendKeys("123456789");
	    driver.findElement(By.xpath("//input[@type='password']")).sendKeys("kgf");
	    driver.findElement(By.xpath("//button[@type='submit']")).click();
	
}
}
