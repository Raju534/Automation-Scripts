package Scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class entervalues
{
   public static void main(String[] args) throws InterruptedException 
   {
	  System.setProperty("webdriver.chrome.driver","./Softwares/chromedriver.exe");
	      WebDriver driver=new ChromeDriver();
	      driver.get("file:///C:/Users/User/Desktop/li.html");
	     WebElement user=driver.findElement(By.tagName("input"));
	       user.clear();
	       user.sendKeys("hello");
	       Thread.sleep(2000);
	       WebElement user2=driver.findElement(By.id("text field"));
	           user2.clear();
	           Thread.sleep(2000);
	           user2.sendKeys("world");
}
}
