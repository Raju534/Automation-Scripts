package Scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class playvideo 
{
   public static void main(String[] args) throws InterruptedException 
   {
	   System.setProperty("webdriver.chrome.driver","./Softwares/chromedriver.exe");
	      WebDriver driver=new ChromeDriver();
	        driver.get("https://www.youtube.com");
	         WebElement  user=driver.findElement(By.tagName("input"));
	            user.sendKeys("kgf movie trailer");
	            driver.findElement(By.id("search-icon-legacy")).click();
	            Thread.sleep(2000);
	            driver.findElement(By.partialLinkText("KGF Trailer Hindi | Yash | Srinidhi | 21st Dec 2018")).click();
	           
}
}
