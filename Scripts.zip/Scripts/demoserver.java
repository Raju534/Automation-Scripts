package Scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class demoserver 
{
   public static void main(String[] args) throws InterruptedException
   {
	 System.setProperty("webdriver.chrome.driver","./Softwares/chromedriver.exe");
	 WebDriver driver=new ChromeDriver();
	 driver.get("https://demoqa.com/webtables");
	 Thread.sleep(4000);
	 driver.findElement(By.xpath("//span[@id='delete-record-1']")).click();
	 driver.findElement(By.xpath("//span[@id='delete-record-2']")).click();
	 driver.findElement(By.xpath("//span[@id='delete-record-3']")).click();
	 
}
}
