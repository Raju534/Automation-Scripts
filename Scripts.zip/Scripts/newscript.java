package Scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class newscript 
{
   public static void main(String[] args) throws InterruptedException
   {
	 System.setProperty("webdriver.chrome.driver","./Softwares/chromedriver.exe");
	    WebDriver driver=new ChromeDriver();
	         driver.get("https://www.youtube.com");
	         WebElement user= driver.findElement(By.tagName("input"));
	         user.sendKeys("kotigobba 3 kannada full movie");
	         
	             driver.findElement(By.id("search-icon-legacy")).click();
	             Thread.sleep(1500);
	             driver.findElement(By.partialLinkText("Kotigobba-3 full movie in Hindi ")).click();
	             
	           
	  
}
}
