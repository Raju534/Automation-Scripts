package Scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class partialllinktext
{
   public static void main(String[] args)
   {
	  System.setProperty("webdriver.chrome.driver","./Softwares/chromedriver.exe");
	     WebDriver driver=new ChromeDriver();
	     driver.get("https://www.google.com/doodles");
	     driver.findElement(By.partialLinkText("kazakh")).click();
}
}
