package Scripts;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class popup4 
{
public static void main(String[] args) 
{
  System.setProperty("webdriver.chrome.driver","./Softwares/chromedriver.exe");
  WebDriver driver=new ChromeDriver();
  driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
  driver.get("https://demoqa.com/browser-windows");
  driver.findElement(By.id("tabButton")).click();
  driver.findElement(By.id("windowButton")).click();
  driver.findElement(By.id("messageWindowButton")).click();
  String pid = driver.getWindowHandle();
  System.out.println(pid);
  Set<String> cpid = driver.getWindowHandles();
	for( String id:cpid)
	{
		driver.switchTo().window(id);
		String url = driver.getCurrentUrl();
		System.out.println(url);
		driver.close();
	}
}
}
