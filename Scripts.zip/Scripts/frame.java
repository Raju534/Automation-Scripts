package Scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class frame 
{
   public static void main(String[] args) throws InterruptedException 
   {
	 System.setProperty("webdriver.chrome.driver","./Softwares/chromedriver.exe");
	 WebDriver driver=new ChromeDriver();
	 driver.get("https://demoqa.com/frames");
	 driver.manage().window().maximize();
	 driver.switchTo().frame("frame1");
	 WebElement frame1add = driver.findElement(By.xpath("//h1[.='This is a sample page']"));
	String frame1text = frame1add.getText();
	System.out.println(frame1text);
	driver.switchTo().defaultContent();
	driver.switchTo().frame("frame2");
	WebElement frame2add = driver.findElement(By.xpath("//h1[.='This is a sample page']"));
	    String frame2text = frame2add.getText();
	    System.out.println(frame2text);
	    driver.switchTo().defaultContent();
	    driver.close();
}
}
