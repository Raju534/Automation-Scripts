package Scripts;

import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class testng 
{
   private static final ITestResult True = null;

@Test
   public void script()
   {
	   Reporter.log("frameworkbegining", false);
	   
   }
  @Test
  public void script1()
  {
	  Reporter.log("frameworkingends",false);
  }
  
}
