package Scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class newww
{
  public static void main(String[] args) throws InterruptedException 
   {
	  System.setProperty("webdriver.chrome.driver","./softwares/chromedriver.exe");
	  WebDriver driver=new ChromeDriver();
	  driver.get("https://accounts.google.com/v3/signin/identifier?dsh=S-1207658146%3A1673193171827447&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&rip=1&sacu=1&service=mail&flowName=GlifWebSignIn&flowEntry=ServiceLogin&ifkv=AeAAQh7mgsXEcFYQ8UFhfhdqk-GgieB6mLYm8RS1IMq7-4lVs_0612RTkfM78WaJz3024jCadBjL6Q");
	  driver.findElement(By.xpath("//input[@type='email']")).sendKeys("1234567890");
	  Thread.sleep(2000);
	  driver.findElement(By.xpath("//span[.='Next']")).click();
	  Thread.sleep(2000);
	  driver.findElement(By.xpath("//input[@type='password']")).sendKeys("1234567890");
	  Thread.sleep(2000);
	  driver.findElement(By.xpath("//span[.='Next']")).click();
	
}
}
