package Scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class css 
{
    public static void main(String[] args) 
    {
	   System.setProperty("webdriver.chrome.driver","./Softwares/chromedriver.exe");
	    WebDriver driver=new ChromeDriver();
	    driver.get("https;//www.youtube.com");
	    driver.findElement(By.cssSelector("input[id='search'")).sendKeys("kgf songs");
	    driver.findElement(By.className("button['id=search-icon-legacy'")).click();
	    
	    
	}
}
