package Scripts;

import org.openqa.selenium.firefox.FirefoxDriver;

public class mozillalaunch
{
   public static void main(String[] args) 
   {
	   String key="webdriver.gecko.driver";
	   String value="./Softwares/geckodriver";
	  System.setProperty(key, value);
	FirefoxDriver    driver=new FirefoxDriver();
	     
}
}
