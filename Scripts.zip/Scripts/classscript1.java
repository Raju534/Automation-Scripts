package Scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class classscript1 
{
  public static void main(String[] args) throws InterruptedException
  {
	System.setProperty("webdriver.chrome.driver","./Softwares/chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("https://demowebshop.tricentis.com/");
	driver.findElement(By.xpath("//a[.='Log in']")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("//input[@id='Email']")).sendKeys("hiremathraju77@gmail.com");
	Thread.sleep(2000);
	driver.findElement(By.xpath("//input[@id='Password']")).sendKeys("Raju@123");
	Thread.sleep(2000);
	driver.findElement(By.xpath("//input[@value='Log in']")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("//a[@href='/electronics']")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("//a[@title='Show products in category Cell phones']")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("//a[.='Smartphone']")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("//a[.='Add your review']")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("//input[@class='review-title']")).sendKeys("super");
	Thread.sleep(2000);
	driver.findElement(By.xpath("//textarea[@id='AddProductReview_ReviewText']")).sendKeys("The product is good");
	Thread.sleep(2000);
	driver.findElement(By.xpath("//input[@id='addproductrating_3']")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("//input[@value='Submit review']")).click();
	
	
	
	
	
	
}
}
