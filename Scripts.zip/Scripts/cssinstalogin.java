package Scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class cssinstalogin
{
  public static void main(String[] args) throws InterruptedException
  {
	  System.setProperty("webdriver.chrome.driver","./Softwares/chromedriver.exe");
	     WebDriver driver=new ChromeDriver();
	       driver.get("https://www.instagram.com");
	       Thread.sleep(2000);
	       driver.findElement(By.cssSelector("input[name='username'")).sendKeys("rockybhai@123gmail.com");
	       driver.findElement(By.cssSelector("input[name='password'")).sendKeys("kgfbhai");
	       Thread.sleep(2000);
	       driver.findElement(By.cssSelector("button[type='submit'")).click();
}
}
