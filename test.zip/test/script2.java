package test;

import org.openqa.selenium.By;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class script2 extends baseclass
{
   @Test
   public static void dissp()
   {
	   String title = driver.getTitle();
	   SoftAssert sf=new SoftAssert();
	   sf.assertEquals(title,"Demo Web Shop");
	   Reporter.log("home page is displayed");
	   driver.findElement(By.xpath("//a[.='Log in']")).click();
	   String page_title = driver.getTitle();
	   sf.assertEquals(page_title,"Demo Web Shop. Login");
	   sf.assertAll();
   }
}
