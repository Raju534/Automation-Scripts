package test;

import org.testng.annotations.Test;

public class testtTest {
  @Test
  public void f() {
  }
}
