package test;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class script extends Base_class
{
  @Test
  public void disp()
  {
	  driver.findElement(By.xpath("//a[.='Log in']")).click();
	  driver.findElement(By.xpath("//input[@id='Email']")).sendKeys("hiremathraju77@gmail.com");
	  driver.findElement(By.xpath("//input[@id='Password']")).sendKeys("Raju@123");
	  driver.findElement(By.xpath("//input[@class='button-1 search-box-button']")).click();
	  
	  
	  
  }		
}
