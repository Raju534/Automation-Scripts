package test;

import org.testng.annotations.Test;

public class enabled
{


@Test(priority=1,invocationCount = 5,enabled = false)
public void signup()
{
	   System.out.println("create an account");
}
@Test(priority=2,invocationCount = 4)
public void login()
{
	  System.out.println("plese login");   
}
@Test(priority=3,invocationCount = 3)
public void cart()
{
	   System.out.println("add items");
}
@Test(priority=4,invocationCount = 2)
public void myorders()
{
	   System.out.println("all the previous orders");
}
@Test(priority=5,invocationCount = 1)
public void logout()
{
	   System.out.println("account loged out");
}
}
