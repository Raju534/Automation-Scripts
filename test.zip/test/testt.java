package test;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class testt extends base_clas
{
   @Test
   public void verification() 
   {
	   String title = driver.getTitle();
	   Assert.assertEquals(title,"Demo Web Shop");
	   Reporter.log("home page is displayed");
	   driver.findElement(By.xpath("//a[.='Log in']")).click();
	   String login_title = driver.getTitle();
	   Assert.assertEquals(login_title,"Demo Web Shop. Login");
	   Reporter.log("Login page is displayed");
   }
}
